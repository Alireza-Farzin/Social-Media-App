import "./online.css";
const Online = ({user}) => {
    return (
        <div>
            <li className="rightBarFriend">
                <div className="rightbarProfilImgContainer">
                    <img className="rightbarProfilImg" src={user.profilePicture} alt="" />
                    <span className="rigthbarOnline"></span>
                </div>
                <span className="rigthbarUsername">{user.username}</span>
            </li>
        </div>
    );
}

export default Online;
