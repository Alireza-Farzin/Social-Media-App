import "./rightbar.css";
import { Users } from "../../dummyData";
import Online from "../online/Online";
const Rightbar = ({ profile }) => {

   let HomeRightbar = () => {
      return (
         <>

            <div className="birthdaContainer">
               <img className="birthadImg" src="assets/gift.png" alt="" />
               <span className="birthadayText"><b>Pola Foster</b> and <b>3 other friends</b> hav  a birthay today </span>
            </div>
            <img className="rightbarAd" src="assets/ad.png" alt="" />
            <h4 className="rightbarTitle">Online Friends</h4>
            <ul className="rightFriendList">
               {Users.map(u => (
                  <Online key={u.id} user={u} />
               ))};
            </ul>

         </>
      )
   }

   let ProfileRightbar = () => {
      return (
         <>
            <h4 className="rightbarTitle">User information </h4>
            <div className="rightbarInfo">
               <div className="rightbarInfoItem">
                  <span className="rightbarInfoKey">City :</span>
                  <span className="rightbarInfoValue">Shraz</span>
               </div>
               <div className="rightbarInfoItem">
                  <span className="rightbarInfoKey">from :</span>
                  <span className="rightbarInfoValue">Fars</span>
               </div>
               <div className="rightbarInfoItem">
                  <span className="rightbarInfoKey">Relationship: :</span>
                  <span className="rightbarInfoValue">Single</span>
               </div>
            </div>
            <h4 className="rightbarTitle">User friends</h4>
            <div className="rightbarFloowings">
               <div className="rightbarFloowing">
                  <img src="assets/person/1.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
               <div className="rightbarFloowing">
                  <img src="assets/person/2.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
               <div className="rightbarFloowing">
                  <img src="assets/person/3.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
               <div className="rightbarFloowing">
                  <img src="assets/person/4.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
               <div className="rightbarFloowing">
                  <img src="assets/person/5.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
               <div className="rightbarFloowing">
                  <img src="assets/person/6.jpeg" className="rightbarFloowingImg" alt="" />
                  <span className="rightbarFloowingNaem">Alireza Farzin</span>
               </div>
            </div>
         </>
      )
   }
   return (
      <div className="rightbar">
         <div className="rightbarWrapper">

            {profile ? <ProfileRightbar /> : <HomeRightbar />}

         </div>
      </div>
   );
}
export default Rightbar;
