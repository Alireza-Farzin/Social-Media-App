import "./register.css";

const Register = () => {
    return (
        <div className="login">
        <div className="loginWrapper">
            <div className="loginLeft">
                <h3 className="loginLogo">Ali Farzin</h3>
                <span className="loginDesc">
                    Connect with friendsd and the world aronud you on Ali Farzin. 
                </span>
            </div>
            <div className="loginRight">
                <div className="loginBox">
                    <input type="text" className="loginInput" placeholder="Username" />
                    <input type="email" className="loginInput" placeholder="Email" />
                    <input type="password" className="loginInput" placeholder="Password" />
                    <input type="password" className="loginInput" placeholder="Password Agin" />
                    <button className="loginButton">Sign Up</button>
                    <button className="loginRegisterButton">Login into Account</button>
                </div>
            </div>
        </div>
    </div>
    );
}

export default Register;
